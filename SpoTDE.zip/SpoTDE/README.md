## MUSIC PLAYER APP JAVA

*mp3 music player developed in java*

muckup - adobe xd
![mockup-adobe-xd](https://user-images.githubusercontent.com/22550929/56622257-ee8aa500-65f4-11e9-8054-b6ef99656d43.png)

user interface - netbean
![program](https://user-images.githubusercontent.com/22550929/56622298-0feb9100-65f5-11e9-8bf8-58caf6aa3f25.png)

#### these three libraries are necessary

* jl1.0
* mp3agic
* kgradientePanel

``` 
java -jar "MusicPlayer.jar"

 ```



